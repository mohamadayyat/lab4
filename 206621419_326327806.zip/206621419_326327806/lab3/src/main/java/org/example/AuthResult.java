package org.example;

public enum AuthResult {
    SUCCESS,
    BLOCKED,
    INVALID_CREDENTIALS,
    USER_NOT_FOUND,
    ERROR
}
